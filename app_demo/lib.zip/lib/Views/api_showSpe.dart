import 'package:flutter/material.dart';
import '../models/specialty.dart';
import '../services/api_service.dart';

class ApiShowSpe extends StatelessWidget {
  const ApiShowSpe({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Danh sách Specialty')),
      body: FutureBuilder<List<Specialty>>(
        future: ApiService.fetchSpecialties(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return Center(child: CircularProgressIndicator());

          if (snapshot.hasError)
            return Center(child: Text('Lỗi: ${snapshot.error}'));

          final specialties = snapshot.data!;
          return ListView.builder(
            itemCount: specialties.length,
            itemBuilder: (context, index) {
              final s = specialties[index];
              final imageUrl =
                  s.imageUrl.startsWith('http')
                      ? s.imageUrl
                      : 'http://localhost:2000${s.imageUrl}';

              return ListTile(
                leading: Image.network(
                  imageUrl,
                  width: 50,
                  errorBuilder: (_, __, ___) => Icon(Icons.image),
                ),
                title: Text(s.name),
              );
            },
          );
        },
      ),
    );
  }
}
