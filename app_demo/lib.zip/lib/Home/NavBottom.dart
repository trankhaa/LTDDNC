import 'package:flutter/material.dart';

import 'HomePage.dart';
import 'NewsPage.dart';
import 'AccountPage.dart';

class Navbottom extends StatefulWidget {
  @override
  _NavbottomState createState() => _NavbottomState();
}

class _NavbottomState extends State<Navbottom> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [HomePage(), NewsPage(), AccountPage()];

  void _onTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_getTitle(_selectedIndex)), centerTitle: true),
      body: IndexedStack(index: _selectedIndex, children: _pages),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onTap,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Trang chủ'),
          BottomNavigationBarItem(
            icon: Icon(Icons.newspaper),
            label: 'Tin tức',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Tài khoản'),
        ],
      ),
    );
  }

  String _getTitle(int index) {
    switch (index) {
      case 0:
        return 'Trang chủ';
      case 1:
        return 'Tin tức';
      case 2:
        return 'Tài khoản';
      default:
        return '';
    }
  }
}
