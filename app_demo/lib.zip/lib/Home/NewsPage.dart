import 'package:flutter/material.dart';

class NewsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Đây là trang Tin tức"));
  }
}
