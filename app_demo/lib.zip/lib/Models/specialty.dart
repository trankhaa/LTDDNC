class Specialty {
  final String id;
  final String name;
  final String imageUrl;

  Specialty({required this.id, required this.name, required this.imageUrl});

  factory Specialty.fromJson(Map<String, dynamic> json) {
    return Specialty(
      id: json['idSpecialty'],
      name: json['nameSpecialty'],
      imageUrl: json['imageUrlSpecialty'],
    );
  }
}
