import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/specialty.dart';

class ApiService {
  static Future<List<Specialty>> fetchSpecialties() async {
    final response = await http.get(
      Uri.parse('http://192.168.218.224:2000/api/Specialty/all'),
    );

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((json) => Specialty.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load specialties');
    }
  }
}
