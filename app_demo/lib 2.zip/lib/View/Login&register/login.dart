// lib/Login®ister/login.dart
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void handleLogin() {
    // Trong thực tế, bạn sẽ kiểm tra email/mật khẩu ở đây.
    // Nếu thông tin đăng nhập đúng, thực hiện chuyển trang.
    
    // Sử dụng pushReplacementNamed để:
    // 1. Chuyển đến màn hình có tên '/nav'.
    // 2. THAY THẾ màn hình Login hiện tại, ngăn người dùng nhấn "Back" để quay lại.
    Navigator.pushReplacementNamed(context, '/nav');
  }

  void handleRegisterPress() {
    // Sử dụng pushNamed để đẩy màn hình Register lên trên màn hình Login.
    Navigator.pushNamed(context, '/register');
  }

  void handleForgotPassPress() { /* Logic quên mật khẩu */ }

  // ... (Phần Style có thể giữ nguyên hoặc rút gọn)

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Stack(
          children: [
            Positioned.fill(
              child: Image.asset('assets/background.png', fit: BoxFit.cover),
            ),
            Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ClipOval(child: Image.asset('assets/logo.png', height: 150, width: 150)),
                    const SizedBox(height: 10),
                    const Text('Healthy Care', style: TextStyle(color: Color(0xFF22668E), fontSize: 25, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 80),
                    TextField(controller: _emailController, decoration: const InputDecoration(labelText: "Nhập email")),
                    const SizedBox(height: 15),
                    TextField(controller: _passwordController, obscureText: true, decoration: const InputDecoration(labelText: "Mật khẩu")),
                    const SizedBox(height: 30),
                    SizedBox(
                      height: 50,
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: handleLogin,
                        child: const Text("Đăng Nhập", style: TextStyle(color: Colors.white, fontSize: 18)),
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text("Bạn chưa có tài khoản?"),
                    const SizedBox(height: 10),
                    SizedBox(
                      height: 50,
                      width: double.infinity,
                      child: OutlinedButton(
                        onPressed: handleRegisterPress,
                        child: const Text("Đăng Ký", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ),
                    ),
                    TextButton(
                      onPressed: handleForgotPassPress,
                      child: const Text("Quên mật khẩu?", style: TextStyle(color: Color(0xFF22668E), decoration: TextDecoration.underline)),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}