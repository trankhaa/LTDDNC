// lib/PageHome/Nav.dart
import 'package:flutter/material.dart';

// Import các trang con từ cùng thư mục PageHome
import 'trangchu.dart';
import 'phieukham.dart';
import 'thongbao.dart';
import 'taikhoan.dart';

// Import màn hình Pagebooking từ thư mục Booking
// Đường dẫn này phải chính xác với cấu trúc của bạn
import 'Booking/Pagebooking.dart';

class NavScreen extends StatefulWidget {
  const NavScreen({super.key});

  @override
  State<NavScreen> createState() => _NavScreenState();
}

class _NavScreenState extends State<NavScreen> {
  // Biến để theo dõi mục nào đang được chọn, bắt đầu từ Trang chủ (index 0)
  int _selectedIndex = 0;

  // Danh sách các Widget (trang) tương ứng với các mục trên thanh điều hướng
  // Thứ tự phải khớp với thứ tự các mục
  static const List<Widget> _pages = <Widget>[
    TrangChuPage(),
    PhieuKhamPage(),
    ThongBaoPage(),
    TaiKhoanPage(),
  ];

  // Hàm được gọi khi người dùng nhấn vào một mục trên thanh Nav
  void _onItemTapped(int index) {
    // Cập nhật lại state để vẽ lại giao diện với trang được chọn
    setState(() {
      _selectedIndex = index;
    });
  }

  // Hàm được gọi khi người dùng nhấn vào nút tròn ở giữa (Floating Action Button)
  void _onFabTapped() {
    // Điều hướng đến trang Pagebooking
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const Pagebooking()),
    );
  }

  // Hàm private để xây dựng từng mục trên thanh Nav, giúp code gọn gàng hơn
  Widget _buildNavItem({
    required IconData icon,
    required String label,
    required int index,
  }) {
    // Kiểm tra xem mục này có đang được chọn hay không
    final bool isSelected = _selectedIndex == index;
    // Đặt màu sắc tương ứng
    final Color color = isSelected ? const Color(0xFF22668E) : Colors.grey;

    return Expanded(
      child: InkWell(
        onTap: () => _onItemTapped(index),
        // Bỏ hiệu ứng gợn sóng mặc định
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, color: color),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Body của Scaffold sẽ hiển thị trang tương ứng với mục đã chọn
      body: _pages.elementAt(_selectedIndex),

      // Nút tròn ở giữa (Floating Action Button)
      floatingActionButton: FloatingActionButton(
        onPressed: _onFabTapped,
        backgroundColor: const Color(0xFF22668E),
        elevation: 4.0,
        shape: const CircleBorder(),
        child: const Icon(Icons.calendar_today, color: Colors.white),
      ),

      // Vị trí của FAB: nằm giữa và "cắt" vào thanh Nav
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

      // Thanh điều hướng dưới cùng
      bottomNavigationBar: BottomAppBar(
        shape:
            const CircularNotchedRectangle(), // Tạo vết cắt hình tròn cho FAB
        notchMargin: 8.0, // Khoảng cách giữa FAB và thanh bar
        child: SizedBox(
          height: 60.0,
          child: Row(
            // Không dùng spaceAround để kiểm soát khoảng cách chính xác hơn
            children: <Widget>[
              _buildNavItem(
                icon: Icons.home_outlined,
                label: 'Trang chủ',
                index: 0,
              ),
              _buildNavItem(
                icon: Icons.assignment_outlined,
                label: 'Phiếu khám',
                index: 1,
              ),
              const SizedBox(width: 60), // Khoảng trống vật lý cho FAB
              _buildNavItem(
                icon: Icons.notifications_outlined,
                label: 'Thông báo',
                index: 2,
              ),
              _buildNavItem(
                icon: Icons.person_outline,
                label: 'Tài khoản',
                index: 3,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
