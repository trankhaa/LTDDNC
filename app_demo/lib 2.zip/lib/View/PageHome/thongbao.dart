import 'package:flutter/material.dart';

class ThongBaoPage extends StatelessWidget {
  const ThongBaoPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: Text("Đây là trang Phiếu Khám")),
    );
  }
}