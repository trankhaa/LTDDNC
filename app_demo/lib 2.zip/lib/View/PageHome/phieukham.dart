import 'package:flutter/material.dart';

class PhieuKhamPage extends StatelessWidget {
  const PhieuKhamPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: Text("Đây là trang Phiếu Khám")),
    );
  }
}