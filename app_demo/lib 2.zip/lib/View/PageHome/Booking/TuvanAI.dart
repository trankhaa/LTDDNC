import 'package:flutter/material.dart';

class TuvanAIScreen extends StatelessWidget {
  const TuvanAIScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Bác sĩ AI")),
      body: const Center(child: Text("Giao diện Tư vấn với AI")),
    );
  }
}
