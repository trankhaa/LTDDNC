// lib/View/PageHome/Booking/doctor_booking_screen.dart
// (Adjust path based on your project structure)

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

// Import Models
import '../../../Model/doctor_full_info_model.dart';
import '../../../Model/booking_confirmation_model.dart';
import '../../../Model/appointment_model.dart';

// Import Services
import '../../../Services/doctor_api_service.dart';
import '../../../Services/booking_api_service.dart';

// Import the new dialog content widget
import './confirm_booking_dialog_content.dart'; // Make sure this path is correct

// User ảo
const String _dummyPatientId = "dummy_patient_001";
const String _dummyPatientEmail = "dummy.patient@example.com";
const String _defaultDoctorAvatarAssetScreen =
    "assets/images/default_avatar.png";

class DoctorBookingScreen extends StatefulWidget {
  final String doctorId; // ID của bác sĩ được truyền vào
  const DoctorBookingScreen({Key? key, required this.doctorId})
      : super(key: key);

  @override
  State<DoctorBookingScreen> createState() => _DoctorBookingScreenState();
}

class _DoctorBookingScreenState extends State<DoctorBookingScreen> {
  final DoctorApiService _doctorApiService = DoctorApiService();
  final BookingApiService _bookingApiService = BookingApiService();

  DoctorFullInfoModel? _doctorFullInfo;
  bool _isLoadingDoctorInfo = true;
  String? _errorLoadingDoctorInfo;

  DateTime? _selectedDate;
  List<String> _availableTimeSlots = [];
  bool _isLoadingSlots = false;
  String? _selectedTimeSlot;

  final TextEditingController _symptomsController = TextEditingController();
  // _isBooking is no longer used for the main button's loader,
  // but could be used if other parts of the screen need to react to booking process.
  // For now, its direct usage for button loading is removed.
  // bool _isBooking = false;

  List<AppointmentModel> _allBookedAppointmentsForDoctor = [];
  bool _isLoadingAllAppointments = false;
  bool _hasLoadedAllAppointments = false;

  @override
  void initState() {
    super.initState();
    print(
      "[DoctorBookingScreen - initState] Received doctorId: ${widget.doctorId}",
    );
    if (widget.doctorId.isEmpty) {
      print(
        "[DoctorBookingScreen - initState] FATAL: doctorId is empty! Cannot proceed.",
      );
      setState(() {
        _isLoadingDoctorInfo = false;
        _errorLoadingDoctorInfo = "Lỗi: ID bác sĩ không hợp lệ.";
      });
      return;
    }
    _fetchInitialData();
  }

  Future<void> _fetchInitialData() async {
    print(
      "[DoctorBookingScreen - _fetchInitialData] Starting initial data fetch...",
    );
    await _fetchDoctorDetails();
    if (_doctorFullInfo != null && !_hasLoadedAllAppointments && mounted) {
      await _fetchAllBookedAppointmentsForDoctor();
    }
    if (_selectedDate != null && _hasLoadedAllAppointments && mounted) {
      print(
        "[DoctorBookingScreen - _fetchInitialData] Has selectedDate, updating slots.",
      );
      _updateAvailableSlotsForSelectedDate();
    }
    print(
      "[DoctorBookingScreen - _fetchInitialData] Initial data fetch completed.",
    );
  }

  Future<void> _fetchDoctorDetails() async {
    if (!mounted) return;
    print(
      "[DoctorBookingScreen - _fetchDoctorDetails] Fetching doctor details for ID: ${widget.doctorId}",
    );
    setState(() {
      _isLoadingDoctorInfo = true;
      _errorLoadingDoctorInfo = null;
    });
    try {
      final data = await _doctorApiService.getDoctorFullInfoById(
        widget.doctorId,
      );
      if (mounted) {
        print(
          "[DoctorBookingScreen - _fetchDoctorDetails] Doctor details fetched. Doctor name: ${data.doctor.name}, Doctor ID from model: ${data.doctor.id}",
        );
        setState(() {
          _doctorFullInfo = data;
          _isLoadingDoctorInfo = false;
        });
      }
    } catch (e) {
      if (mounted) {
        final errorMessage = e.toString().replaceFirst("Exception: ", "");
        print(
          "[DoctorBookingScreen - _fetchDoctorDetails] Error: $errorMessage",
        );
        setState(() {
          _errorLoadingDoctorInfo = "Lỗi tải thông tin bác sĩ: $errorMessage";
          _isLoadingDoctorInfo = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Lỗi tải thông tin bác sĩ: $errorMessage"),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _fetchAllBookedAppointmentsForDoctor() async {
    if (!mounted || _isLoadingAllAppointments || _doctorFullInfo == null) {
      return;
    }
    print(
      "[DoctorBookingScreen - _fetchAllBookedAppointmentsForDoctor] Fetching all booked appointments for doctor ID: ${widget.doctorId}",
    );
    setState(() {
      _isLoadingAllAppointments = true;
      _isLoadingSlots = true; // Also set loading slots here
    });
    try {
      final appointments = await _bookingApiService.getAppointmentsByDoctorId(
        widget.doctorId,
      );
      if (mounted) {
        setState(() {
          _allBookedAppointmentsForDoctor = appointments;
          _hasLoadedAllAppointments = true;
          _isLoadingAllAppointments = false;
          if (_selectedDate != null) {
            _updateAvailableSlotsForSelectedDate();
          } else {
            _isLoadingSlots = false; // Ensure slots loading is false if no date
          }
        });
      }
    } catch (e) {
      if (mounted) {
        final errorMessage = e.toString().replaceFirst("Exception: ", "");
        print(
          "[DoctorBookingScreen - _fetchAllBookedAppointmentsForDoctor] Error: $errorMessage",
        );
        setState(() {
          _isLoadingAllAppointments = false;
          _isLoadingSlots = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Lỗi tải lịch hẹn đã đặt: $errorMessage'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  List<String> _generatePossibleStartTimesForDay(DateTime forDate) {
    // ... (Your existing _generatePossibleStartTimesForDay logic - NO CHANGE)
    print(
      "[DoctorBookingScreen - _generatePossibleStartTimesForDay] Generating for date: $forDate",
    );
    if (_doctorFullInfo?.doctorSchedules == null ||
        _doctorFullInfo!.doctorSchedules.isEmpty) {
      print(
        "[DoctorBookingScreen - _generatePossibleStartTimesForDay] No DoctorSchedules found.",
      );
      return [];
    }

    final schedule = _doctorFullInfo!.doctorSchedules[0];
    final examinationTime = schedule.examinationTime;
    final startTimeString = schedule.startTime;
    final endTimeString = schedule.endTime;
    final breakStartTimeString = schedule.breakStartTime;
    final breakEndTimeString = schedule.breakEndTime;

    if (examinationTime == null ||
        examinationTime <= 0 ||
        startTimeString == null ||
        startTimeString.isEmpty ||
        endTimeString == null ||
        endTimeString.isEmpty) {
      print(
        "[DoctorBookingScreen - _generatePossibleStartTimesForDay] Invalid schedule info: Start='$startTimeString', End='$endTimeString', ExamTime=$examinationTime",
      );
      return [];
    }

    final List<String> possibleStartTimes = [];
    try {
      final startH = int.parse(startTimeString.split(':')[0]);
      final startM = int.parse(startTimeString.split(':')[1]);
      final endH = int.parse(endTimeString.split(':')[0]);
      final endM = int.parse(endTimeString.split(':')[1]);

      DateTime currentTimeSlotStart = DateTime(
        forDate.year,
        forDate.month,
        forDate.day,
        startH,
        startM,
      );
      final dayEndTimeBoundary = DateTime(
        forDate.year,
        forDate.month,
        forDate.day,
        endH,
        endM,
      );

      DateTime? breakStartTimeObj;
      DateTime? breakEndTimeObj;

      if (breakStartTimeString != null &&
          breakStartTimeString.isNotEmpty &&
          breakEndTimeString != null &&
          breakEndTimeString.isNotEmpty) {
        try {
          final breakStartH = int.parse(breakStartTimeString.split(':')[0]);
          final breakStartM = int.parse(breakStartTimeString.split(':')[1]);
          final breakEndH = int.parse(breakEndTimeString.split(':')[0]);
          final breakEndM = int.parse(breakEndTimeString.split(':')[1]);
          breakStartTimeObj = DateTime(
            forDate.year,
            forDate.month,
            forDate.day,
            breakStartH,
            breakStartM,
          );
          breakEndTimeObj = DateTime(
            forDate.year,
            forDate.month,
            forDate.day,
            breakEndH,
            breakEndM,
          );
        } catch (e) {
          print(
            "[DoctorBookingScreen - _generatePossibleStartTimesForDay] Error parsing breakTime: '$breakStartTimeString' - '$breakEndTimeString'. Error: $e. Skipping break time.",
          );
        }
      }
      print(
        "[DoctorBookingScreen - _generatePossibleStartTimesForDay] Generating slots from $startTimeString to $endTimeString, exam time: $examinationTime min. Break: $breakStartTimeString - $breakEndTimeString",
      );

      while (currentTimeSlotStart.isBefore(dayEndTimeBoundary)) {
        DateTime slotEndTime = currentTimeSlotStart.add(
          Duration(minutes: examinationTime),
        );

        if (slotEndTime.isAfter(dayEndTimeBoundary)) {
          if (!slotEndTime.isAtSameMomentAs(dayEndTimeBoundary)) {
            // Allow slot if it ends exactly at endTimeBoundary
            break;
          }
        }

        bool isDuringBreak = false;
        if (breakStartTimeObj != null && breakEndTimeObj != null) {
          if (currentTimeSlotStart.isBefore(breakEndTimeObj) &&
              slotEndTime.isAfter(breakStartTimeObj)) {
            isDuringBreak = true;
          }
        }

        if (!isDuringBreak) {
          possibleStartTimes.add(
            DateFormat('HH:mm').format(currentTimeSlotStart),
          );
        }
        currentTimeSlotStart = slotEndTime;
      }
      print(
        "[DoctorBookingScreen - _generatePossibleStartTimesForDay] Generated ${possibleStartTimes.length} possible slots: $possibleStartTimes",
      );
    } catch (e) {
      print(
        "[DoctorBookingScreen - _generatePossibleStartTimesForDay] Error creating possible slots: $e. Check startTime/endTime format ('HH:mm') in DoctorScheduleModel.",
      );
      return [];
    }
    return possibleStartTimes;
  }

  void _updateAvailableSlotsForSelectedDate() {
    // ... (Your existing _updateAvailableSlotsForSelectedDate logic - NO CHANGE)
    if (!mounted) return;
    if (_selectedDate == null ||
        !_hasLoadedAllAppointments ||
        _doctorFullInfo == null) {
      print(
        "[DoctorBookingScreen - _updateAvailableSlotsForSelectedDate] Skipped: selectedDateIsNull=${_selectedDate == null}, hasLoadedAllAppointments=$_hasLoadedAllAppointments, doctorFullInfoIsNull=${_doctorFullInfo == null}",
      );
      if (mounted)
        setState(() {
          _availableTimeSlots = [];
          _isLoadingSlots = false;
        });
      return;
    }
    print(
      "[DoctorBookingScreen - _updateAvailableSlotsForSelectedDate] Updating for date: $_selectedDate",
    );
    if (mounted)
      setState(() {
        _isLoadingSlots = true;
      });

    final allPossibleStartTimes = _generatePossibleStartTimesForDay(
      _selectedDate!,
    );
    if (!mounted) return;

    // Ensure dates are compared consistently (UTC and only date part)
    final selectedDateOnlyUtc = DateTime.utc(
      _selectedDate!.year,
      _selectedDate!.month,
      _selectedDate!.day,
    );

    final bookedSlotsForDay =
        _allBookedAppointmentsForDoctor
            .where((app) {
              // app.date is already UTC from AppointmentModel.fromJson
              DateTime appDateOnlyUtc = DateTime.utc(
                app.date.year,
                app.date.month,
                app.date.day,
              );
              // print("Comparing appDate: $appDateOnlyUtc with selectedDate: $selectedDateOnlyUtc. Slot: ${app.startTimeOfSlot}");
              return appDateOnlyUtc.isAtSameMomentAs(selectedDateOnlyUtc);
            })
            .map((app) => app.startTimeOfSlot)
            .toSet();

    print(
      "[DoctorBookingScreen - _updateAvailableSlotsForSelectedDate] Possible slots for $_selectedDate: $allPossibleStartTimes",
    );
    print(
      "[DoctorBookingScreen - _updateAvailableSlotsForSelectedDate] Booked slots for $_selectedDate (start times): $bookedSlotsForDay",
    );

    final available =
        allPossibleStartTimes
            .where(
              (possibleSlotStartTime) =>
                  !bookedSlotsForDay.contains(possibleSlotStartTime),
            )
            .toList();

    print(
      "[DoctorBookingScreen - _updateAvailableSlotsForSelectedDate] Available slots for $_selectedDate: $available",
    );

    if (mounted) {
      setState(() {
        _availableTimeSlots = available;
        _isLoadingSlots = false;
      });

      if (available.isEmpty && allPossibleStartTimes.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Không có lịch trống cho ngày đã chọn.'),
          ),
        );
      } else if (allPossibleStartTimes.isEmpty &&
          _doctorFullInfo!.doctorSchedules.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Không thể tạo khung giờ từ lịch làm việc của bác sĩ cho ngày này.',
            ),
          ),
        );
      } else if (_doctorFullInfo!.doctorSchedules.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Bác sĩ không có lịch làm việc được định nghĩa.'),
          ),
        );
      }
    }
  }

  Future<void> _onDateSelectedFromPicker(DateTime date) async {
    // ... (Your existing _onDateSelectedFromPicker logic - NO CHANGE)
    if (!mounted) return;
    print(
      "[DoctorBookingScreen - _onDateSelectedFromPicker] Date selected: $date",
    );
    setState(() {
      _selectedDate = date;
      _selectedTimeSlot = null;
      _availableTimeSlots = [];
      _isLoadingSlots = true;
    });

    if (!_hasLoadedAllAppointments) {
      print(
        "[DoctorBookingScreen - _onDateSelectedFromPicker] All appointments not loaded yet, fetching...",
      );
      await _fetchAllBookedAppointmentsForDoctor();
    } else {
      print(
        "[DoctorBookingScreen - _onDateSelectedFromPicker] All appointments already loaded, updating slots for selected date.",
      );
      _updateAvailableSlotsForSelectedDate();
    }
  }

  // NEW: This method contains the actual booking API call and logic
  Future<void> _executeActualBooking() async {
    // This logic was originally in _handleConfirmBooking
    // Validations for _doctorFullInfo, _selectedDate, _selectedTimeSlot are assumed to be done before calling this.
    final String currentDoctorId = _doctorFullInfo!.doctor.id;

    try {
      final hasBookedToday = await _bookingApiService
          .checkUserDailyBookingLimit(
        _dummyPatientId,
        currentDoctorId,
        _selectedDate!,
      );
      if (!mounted) return;
      if (hasBookedToday) {
        print(
          "[DoctorBookingScreen - _executeActualBooking] User has already booked today with this doctor.",
        );
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Bạn đã có lịch hẹn với bác sĩ ${_doctorFullInfo!.doctor.name ?? ""} vào ngày ${DateFormat('dd/MM/yyyy', 'vi_VN').format(_selectedDate!)}. Mỗi ngày chỉ được đặt 1 lịch.',
            ),
            backgroundColor: Colors.orange,
          ),
        );
        return; // Important to return to prevent further execution
      }

      final int examinationTime =
          _doctorFullInfo!.examinationTimePerSlot ?? 30;
      final String startTimeString = _selectedTimeSlot!;

      final timeFormat = DateFormat('HH:mm');
      DateTime parsedStartTime;
      try {
        parsedStartTime = timeFormat.parse(startTimeString);
      } catch (e) {
        print(
          "[DoctorBookingScreen - _executeActualBooking] Error parsing _selectedTimeSlot: '$startTimeString'. Error: $e",
        );
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Lỗi định dạng giờ đã chọn.'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      final DateTime startDateTime = DateTime(
        _selectedDate!.year,
        _selectedDate!.month,
        _selectedDate!.day,
        parsedStartTime.hour,
        parsedStartTime.minute,
      );
      final DateTime endDateTime = startDateTime.add(
        Duration(minutes: examinationTime),
      );
      final String endTimeStringForSlot = timeFormat.format(endDateTime);
      final String slotForBooking = "$startTimeString-$endTimeStringForSlot";
      print(
        "[DoctorBookingScreen - _executeActualBooking] Calculated slotForBooking: $slotForBooking",
      );

      final DateTime selectedDateUtc = DateTime.utc(
        _selectedDate!.year,
        _selectedDate!.month,
        _selectedDate!.day,
      );

      final bookingData = BookingConfirmationModel(
        nameDr: _doctorFullInfo!.doctor.name ?? 'Không rõ tên',
        doctorId: currentDoctorId,
        slot: slotForBooking,
        patientId: _dummyPatientId,
        patientEmail: _dummyPatientEmail,
        date: selectedDateUtc,
        symptoms: _symptomsController.text.trim(),
      );
      print(
        "[DoctorBookingScreen - _executeActualBooking] Booking data to send: ${bookingData.toJson()}",
      );

      final response = await _bookingApiService.bookAppointment(bookingData);
      if (!mounted) return;
      print(
        "[DoctorBookingScreen - _executeActualBooking] Booking API response: $response",
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            response['message'] as String? ?? 'Đặt lịch thành công!',
          ),
          backgroundColor: Colors.green,
        ),
      );

      print(
        "[DoctorBookingScreen - _executeActualBooking] Booking successful, refreshing appointments and slots...",
      );
      await _fetchAllBookedAppointmentsForDoctor();
      if (mounted) {
        setState(() {
          _selectedTimeSlot = null;
        });
      }
    } catch (e) {
      if (mounted) {
        print(
          "[DoctorBookingScreen - _executeActualBooking] Error during booking: $e",
        );
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(e.toString().replaceFirst("Exception: ", "")),
            backgroundColor: Colors.red,
          ),
        );
      }
      rethrow; // Rethrow so the dialog can handle its state if needed, or just pop.
    }
  }

  // MODIFIED: This method now shows the confirmation dialog
  Future<void> _showBookingConfirmationDialog() async {
    if (!mounted) return;
    print(
      "[DoctorBookingScreen - _showBookingConfirmationDialog] Attempting to show confirmation dialog...",
    );

    if (_doctorFullInfo == null ||
        _selectedDate == null ||
        _selectedTimeSlot == null ||
        _doctorFullInfo!.doctor.id.isEmpty) {
      print(
        "[DoctorBookingScreen - _showBookingConfirmationDialog] Validation failed: Missing doctor info, selected date, time slot, or doctor ID.",
      );
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Vui lòng chọn ngày, giờ khám và đảm bảo thông tin bác sĩ đã tải!',
          ),
        ),
      );
      return;
    }

    // Prepare data for the dialog
    final String doctorName = _doctorFullInfo!.doctor.name ?? "Không rõ tên";
    final DateTime selectedDate = _selectedDate!;
    final String selectedTimeSlotStartTime = _selectedTimeSlot!;
    final int examinationTime = _doctorFullInfo!.examinationTimePerSlot ?? 30;
    final double? consultationFee = _doctorFullInfo!.consultationFee;
    final String symptoms = _symptomsController.text.trim();

    await showDialog(
      context: context,
      barrierDismissible: false, // User must tap a button to close
      builder: (BuildContext dialogContext) {
        return ConfirmBookingDialogContent(
          patientName: _dummyPatientId, // Using ID as name, you can change this
          patientEmail: _dummyPatientEmail,
          doctorName: doctorName,
          selectedDate: selectedDate,
          selectedTimeSlotStartTime: selectedTimeSlotStartTime,
          examinationTimeMinutes: examinationTime,
          consultationFee: consultationFee,
          symptoms: symptoms,
          onConfirmBooking: () async {
            try {
              await _executeActualBooking(); // Call the actual booking logic
              if (mounted) Navigator.of(dialogContext).pop(); // Close dialog on success
            } catch (e) {
              // Error is handled by _executeActualBooking (shows SnackBar)
              if (mounted) Navigator.of(dialogContext).pop(); // Close dialog on error too
            }
          },
        );
      },
    );
  }

  @override
  void dispose() {
    print("[DoctorBookingScreen - dispose] Disposing screen.");
    _symptomsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // ... (Your existing build method structure - NO CHANGE to overall structure)
    print(
      "[DoctorBookingScreen - build] Rebuilding UI. isLoadingDoctorInfo: $_isLoadingDoctorInfo, errorLoadingDoctorInfo: $_errorLoadingDoctorInfo, _doctorFullInfo is null: ${_doctorFullInfo == null}",
    );
    return Scaffold(
      appBar: AppBar(
        title: Text(_doctorFullInfo?.doctor.name ?? 'Đặt lịch khám'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    // ... (Your existing _buildBody logic for loading/error/null states - NO CHANGE)
    if (_isLoadingDoctorInfo) {
      print(
        "[DoctorBookingScreen - _buildBody] Showing loading indicator for doctor info.",
      );
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorLoadingDoctorInfo != null) {
      print(
        "[DoctorBookingScreen - _buildBody] Showing error for doctor info: $_errorLoadingDoctorInfo",
      );
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, color: Colors.red, size: 48),
              const SizedBox(height: 10),
              Text(
                _errorLoadingDoctorInfo!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.red, fontSize: 16),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                icon: const Icon(Icons.refresh),
                label: const Text('Thử lại'),
                onPressed: _fetchInitialData,
              ),
            ],
          ),
        ),
      );
    }
    if (_doctorFullInfo == null) {
      print(
        "[DoctorBookingScreen - _buildBody] doctorFullInfo is null after loading, showing 'not found'.",
      );
      return const Center(child: Text("Không tìm thấy thông tin bác sĩ."));
    }

    print(
      "[DoctorBookingScreen - _buildBody] Building main booking UI for doctor: ${_doctorFullInfo!.doctor.name}",
    );
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildDoctorHeader(),
          const SizedBox(height: 24),
          _buildDatePickerSection(),
          _buildTimeSlotSection(),
          const SizedBox(height: 24),
          _buildSymptomsInput(),
          const SizedBox(height: 32),
          _buildBookingButton(), // This will use the modified logic
        ],
      ),
    );
  }

  Widget _buildDoctorHeader() {
    // ... (Your existing _buildDoctorHeader - NO CHANGE)
    final doctor = _doctorFullInfo!.doctor;
    final doctorDetail = _doctorFullInfo!.doctorDetail;
    final imageUrl = _doctorFullInfo!.doctorImageUrl;

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 40,
              backgroundColor: Colors.grey.shade200,
              backgroundImage:
                  (imageUrl != null && imageUrl.isNotEmpty)
                      ? NetworkImage(imageUrl)
                      : const AssetImage(_defaultDoctorAvatarAssetScreen)
                          as ImageProvider,
              onBackgroundImageError:
                  (imageUrl != null && imageUrl.isNotEmpty)
                      ? (exception, stackTrace) {
                        print(
                          "[Flutter] DoctorBookingScreen - _buildDoctorHeader: Error loading doctor image '$imageUrl': $exception",
                        );
                      }
                      : null,
              child:
                  (imageUrl == null || imageUrl.isEmpty)
                      ? const Icon(Icons.person, size: 40, color: Colors.grey)
                      : null,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    doctor.name ?? 'Bác sĩ không tên',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (_doctorFullInfo!.specialtyName != null &&
                      _doctorFullInfo!.specialtyName!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Text(
                        _doctorFullInfo!.specialtyName!,
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.grey.shade700,
                        ),
                      ),
                    ),
                  if (doctorDetail?.degree != null &&
                      doctorDetail!.degree!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Text(
                        doctorDetail.degree!,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.blue.shade700,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                  if (_doctorFullInfo!.consultationFee != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        'Phí khám: ${NumberFormat.currency(locale: 'vi_VN', symbol: 'VNĐ').format(_doctorFullInfo!.consultationFee)}',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.green.shade700,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDatePickerSection() {
    // ... (Your existing _buildDatePickerSection - NO CHANGE)
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Chọn ngày khám:',
          style: Theme.of(
            context,
          ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          icon: const Icon(Icons.calendar_today),
          label: Text(
            _selectedDate == null
                ? "Nhấn để chọn ngày"
                : DateFormat(
                  'dd/MM/yyyy (EEEE)',
                  'vi_VN',
                ).format(_selectedDate!),
            style: const TextStyle(fontSize: 16),
          ),
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(double.infinity, 48),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          onPressed: () async {
            final DateTime? pickedDate = await showDatePicker(
              context: context,
              initialDate:
                  _selectedDate ?? DateTime.now().add(const Duration(days: 1)),
              firstDate: DateTime.now().add(const Duration(days: 1)),
              lastDate: DateTime.now().add(const Duration(days: 60)),
              locale: const Locale('vi', 'VN'),
            );
            if (pickedDate != null && pickedDate != _selectedDate) {
              _onDateSelectedFromPicker(pickedDate);
            }
          },
        ),
      ],
    );
  }

  Widget _buildTimeSlotSection() {
    // ... (Your existing _buildTimeSlotSection - NO CHANGE)
    print(
      "[DoctorBookingScreen - _buildTimeSlotSection] Building. isLoadingSlots: $_isLoadingSlots, selectedDate: $_selectedDate, availableSlots: ${_availableTimeSlots.length}",
    );
    if (_selectedDate == null) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0),
        child: Center(
          child: Text(
            'Vui lòng chọn ngày khám để xem giờ trống.',
            style: TextStyle(color: Colors.grey.shade700),
          ),
        ),
      );
    }

    if (_isLoadingSlots) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 20.0),
        child: Center(child: CircularProgressIndicator()),
      );
    }

    if (_availableTimeSlots.isEmpty) {
      // Chỉ hiển thị nếu đã tải xong và không có slot
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0),
        child: Center(
          child: Text(
            'Không có khung giờ trống cho ngày này.',
            style: TextStyle(color: Colors.grey.shade700),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Chọn giờ khám:',
          style: Theme.of(
            context,
          ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8.0,
          runSpacing: 8.0,
          children:
              _availableTimeSlots.map((slotStartTime) {
                final isSelected = _selectedTimeSlot == slotStartTime;
                return ChoiceChip(
                  label: Text(
                    slotStartTime,
                    style: TextStyle(
                      color:
                          isSelected
                              ? Colors.white
                              : Theme.of(context).textTheme.bodyLarge?.color ??
                                  Colors.black87,
                    ),
                  ),
                  selected: isSelected,
                  onSelected: (selected) {
                    setState(() {
                      _selectedTimeSlot = selected ? slotStartTime : null;
                    });
                  },
                  selectedColor: Theme.of(context).primaryColor,
                  backgroundColor: Colors.grey.shade200,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                );
              }).toList(),
        ),
      ],
    );
  }

  Widget _buildSymptomsInput() {
    // ... (Your existing _buildSymptomsInput - NO CHANGE)
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Triệu chứng/Lý do khám (không bắt buộc):',
          style: Theme.of(
            context,
          ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _symptomsController,
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            hintText: "Mô tả ngắn gọn các triệu chứng của bạn...",
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 10,
            ),
          ),
          maxLines: 3,
          textInputAction: TextInputAction.done,
        ),
      ],
    );
  }

  // MODIFIED: _buildBookingButton now calls _showBookingConfirmationDialog
  // and does not show a loader itself.
  Widget _buildBookingButton() {
    // Determine if the button should be enabled
    bool canAttemptBooking = _doctorFullInfo != null &&
        _selectedDate != null &&
        _selectedTimeSlot != null &&
        _doctorFullInfo!.doctor.id.isNotEmpty;

    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: canAttemptBooking ? _showBookingConfirmationDialog : null,
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: const Text('Xác nhận Đặt lịch'), // Text is static now
      ),
    );
  }
}