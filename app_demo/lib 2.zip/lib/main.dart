// main.dart
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart'; // ✅ Dòng này sẽ không báo lỗi nữa

// Import các màn hình với đường dẫn chính xác dựa trên cấu trúc của bạn
import 'View/Login&register/login.dart';
import 'View/Login&register/register.dart';
import 'View/PageHome/Nav.dart'; // Màn hình chính chứa thanh Nav
// ... bạn có thể cần import intl nếu dùng initializeDateFormatting
// import 'package:intl/date_symbol_data_local.dart';


void main() {
  // Nếu bạn sử dụng initializeDateFormatting cho tiếng Việt, bạn cần làm main() thành async
  // WidgetsFlutterBinding.ensureInitialized(); // Cần thiết nếu main là async
  // await initializeDateFormatting('vi_VN', null); // Nếu bạn cần tiếng Việt cho DateFormat
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Healthy Care App',
      debugShowCheckedModeBanner: false,

      // === CẤU HÌNH LOCALIZATION CHO DATEPICKER ===
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en', ''), // Tiếng Anh
        Locale('vi', ''), // Tiếng Việt
        // Thêm các ngôn ngữ khác nếu bạn muốn hỗ trợ
      ],
      // locale: const Locale('vi'), // Tùy chọn: Đặt locale mặc định nếu muốn
      // ============================================
      
      home: const LoginScreen(), 
      
      routes: {
        '/nav': (context) => const NavScreen(),
        '/register': (context) => const RegisterScreen(),
        // Bạn có thể thêm các route khác ở đây nếu cần
      },
    );
  }
}