// lib/Services/booking_api_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;

// Import các model cần thiết
import '../Model/booking_confirmation_model.dart';
import '../Model/appointment_model.dart'; // ✅ Model cho các lịch hẹn đã đặt

// Hằng số base URL
const String _apiBaseUrl = "http://192.168.29.224:2000"; // Chỉ host và port

class BookingApiService {
  // --- Các hàm đã có (bookAppointment, checkSlotTaken, checkUserDailyBookingLimit) ---
  // --- Chúng giữ nguyên như bạn đã có ---

  Future<Map<String, dynamic>> bookAppointment(BookingConfirmationModel bookingData) async {
    final Uri uri = Uri.parse('$_apiBaseUrl/api/booking/create');
    print('[API Call] POST: $uri with body: ${json.encode(bookingData.toJson())}');
    try {
      final response = await http.post(
        uri,
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'Accept': 'application/json',
        },
        body: json.encode(bookingData.toJson()),
      ).timeout(const Duration(seconds: 20));

      final String responseBody = utf8.decode(response.bodyBytes);
      final Map<String, dynamic> decodedJson = jsonDecode(responseBody);

      if (response.statusCode == 200 || response.statusCode == 201) {
        print('[API Response] bookAppointment SUCCESS: $responseBody');
        return decodedJson;
      } else {
        print('[API Response] bookAppointment FAILED (${response.statusCode}): $responseBody');
        String errorMessage = decodedJson['message'] as String? ?? 'Đặt lịch thất bại (${response.statusCode}).';
        if (response.statusCode == 409) {
          errorMessage = decodedJson['message'] as String? ?? "Khung giờ này vừa có người khác đặt. Vui lòng chọn lại.";
        }
        throw Exception(errorMessage);
      }
    } catch (e) {
      print('[API Exception] bookAppointment: $e');
      if (e is http.ClientException || e.toString().contains('SocketException') || e.toString().contains('Failed host lookup')) {
        throw Exception('Không thể kết nối đến máy chủ để đặt lịch. Vui lòng kiểm tra kết nối mạng.');
      }
      throw Exception('Lỗi khi đặt lịch: ${e.toString().replaceFirst("Exception: ", "")}');
    }
  }

  Future<bool> checkSlotTaken(String doctorId, DateTime date, String slot) async {
    final dateString = "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
    final queryParameters = {'doctorId': doctorId, 'date': dateString, 'slot': slot};
    final Uri uri = Uri.parse('$_apiBaseUrl/api/booking/check-slot').replace(queryParameters: queryParameters);
    print('[API Call] GET: $uri');
    try {
      final response = await http.get(uri, headers: {'Accept': 'application/json'}).timeout(const Duration(seconds: 10));
      final String responseBody = utf8.decode(response.bodyBytes);
      final Map<String, dynamic> decodedJson = jsonDecode(responseBody);
      if (response.statusCode == 200) {
        return decodedJson['isTaken'] as bool? ?? true;
      } else {
        print('[API Response] checkSlotTaken FAILED (${response.statusCode}): $responseBody');
        throw Exception('Lỗi kiểm tra slot: ${decodedJson['message'] ?? response.statusCode}');
      }
    } catch (e) {
      print('[API Exception] checkSlotTaken: $e');
      throw Exception('Lỗi kết nối khi kiểm tra slot: ${e.toString()}');
    }
  }

  Future<bool> checkUserDailyBookingLimit(String patientId, String doctorId, DateTime date) async {
    final dateString = "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
    final queryParameters = {'patientId': patientId, 'doctorId': doctorId, 'date': dateString};
    final Uri uri = Uri.parse('$_apiBaseUrl/api/booking/check-daily-limit').replace(queryParameters: queryParameters);
    print('[API Call] GET: $uri');
    try {
      final response = await http.get(uri, headers: {'Accept': 'application/json'}).timeout(const Duration(seconds: 10));
      final String responseBody = utf8.decode(response.bodyBytes);
      final Map<String, dynamic> decodedJson = jsonDecode(responseBody);
      if (response.statusCode == 200) {
        return decodedJson['hasBookingToday'] as bool? ?? true;
      } else if (response.statusCode == 404 && (decodedJson['message'] as String?)?.contains('Patient has no booking with this doctor today') == true) {
        return false;
      } else {
        print('[API Response] checkUserDailyBookingLimit FAILED (${response.statusCode}): $responseBody');
        throw Exception('Lỗi kiểm tra giới hạn đặt lịch: ${decodedJson['message'] ?? response.statusCode}');
      }
    } catch (e) {
      print('[API Exception] checkUserDailyBookingLimit: $e');
      throw Exception('Lỗi kết nối khi kiểm tra giới hạn đặt lịch: ${e.toString()}');
    }
  }

  // ✅ HÀM LẤY DANH SÁCH CÁC LỊCH HẸN ĐÃ ĐẶT CỦA BÁC SĨ
  // API Backend: GET /api/booking/appointments/doctor/{doctorId}
  // API này có thể nhận thêm query params như startDate, endDate, hoặc month để lọc bớt dữ liệu từ server.
  // Hiện tại, chúng ta giả sử nó trả về TẤT CẢ lịch hẹn của bác sĩ nếu không có params lọc.
  Future<List<AppointmentModel>> getAppointmentsByDoctorId(String doctorId) async {
    // Endpoint này trong BookingController.cs của bạn là: [HttpGet("appointments/doctor/{doctorId}")]
    final Uri uri = Uri.parse('$_apiBaseUrl/api/booking/appointments/doctor/$doctorId');
    print('[API Call] GET (lấy lịch hẹn đã đặt của bác sĩ): $uri');

    try {
      final response = await http.get(
        uri,
        headers: {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 30)); // Tăng timeout một chút nếu có thể có nhiều lịch hẹn

      if (response.statusCode == 200) {
        final String responseBody = utf8.decode(response.bodyBytes);
        // API backend nên trả về một JSON array các đối tượng lịch hẹn
        final List<dynamic> decodedList = jsonDecode(responseBody);

        if (decodedList.isEmpty) {
          print('[API Response] getAppointmentsByDoctorId: Không có lịch hẹn nào được tìm thấy.');
          return []; // Trả về mảng rỗng nếu backend trả về mảng rỗng
        }

        // Parse mỗi item trong list thành AppointmentModel
        List<AppointmentModel> appointments = decodedList
            .map((item) => AppointmentModel.fromJson(item as Map<String, dynamic>))
            .toList();
        print('[API Response] getAppointmentsByDoctorId: Tải thành công ${appointments.length} lịch hẹn.');
        return appointments;

      } else if (response.statusCode == 404) {
        // Nếu backend trả về 404 khi không có lịch hẹn (không khuyến khích, nên là 200 với mảng rỗng)
        // Hoặc khi doctorId không tồn tại.
        print('[API Response] getAppointmentsByDoctorId (404): Không tìm thấy lịch hẹn hoặc bác sĩ. Body: ${utf8.decode(response.bodyBytes)}');
        return []; // Coi như không có lịch hẹn nào
      }
      else {
        // Xử lý các lỗi HTTP khác
        final String errorBody = utf8.decode(response.bodyBytes);
        print('[API Response] getAppointmentsByDoctorId FAILED (${response.statusCode}): $errorBody');
        String errorMessage = 'Lỗi không xác định khi lấy danh sách lịch hẹn';
        try {
            final Map<String, dynamic> errorJson = jsonDecode(errorBody);
            errorMessage = errorJson['message'] as String? ?? errorMessage;
        } catch (_) { /* Ignore parsing error nếu body không phải JSON */ }
        throw Exception(errorMessage);
      }
    } catch (e) {
      print('[API Exception] getAppointmentsByDoctorId: $e');
      if (e is http.ClientException || e.toString().contains('SocketException') || e.toString().contains('Failed host lookup')) {
        throw Exception('Không thể kết nối đến máy chủ để lấy danh sách lịch hẹn. Vui lòng kiểm tra kết nối mạng.');
      }
      // Ném lại lỗi để UI có thể xử lý
      throw Exception('Lỗi kết nối hoặc xử lý dữ liệu khi lấy danh sách lịch hẹn: ${e.toString().replaceFirst("Exception: ", "")}');
    }
  }

  // XÓA hàm getAvailableTimeSlots vì logic này sẽ được xử lý ở client
  // Future<List<String>> getAvailableTimeSlots(String doctorId, DateTime date) async { ... }
}